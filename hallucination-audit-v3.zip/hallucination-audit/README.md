# Hallucination Audit Trail

Detect hallucinations in LLM-generated text with visual highlighting and an audit report panel.

---

## Folder Structure

```
hallucination-audit/
├── app.py               # Flask backend + AI logic
├── requirements.txt
├── templates/
│   └── index.html       # Single-file frontend (HTML + CSS + JS)
└── README.md
```

---

## Quick Start (5 minutes)

### 1. Install Python dependencies

```bash
cd hallucination-audit
pip install -r requirements.txt
```

### 2. Set your Anthropic API key (optional — app works without it in demo mode)

**Mac/Linux:**
```bash
export ANTHROPIC_API_KEY="sk-ant-..."
```

**Windows (CMD):**
```cmd
set ANTHROPIC_API_KEY=sk-ant-...
```

**Windows (PowerShell):**
```powershell
$env:ANTHROPIC_API_KEY="sk-ant-..."
```

### 3. Run the server

```bash
python app.py
```

### 4. Open in browser

```
http://localhost:5000
```

---

## Features

| Feature | Details |
|---|---|
| Claim extraction | LLM extracts all factual claims from pasted text |
| Verification | Each claim classified: Verified ✅ / Unverified ⚠️ / Hallucination ❌ |
| Confidence score | 0–100% per claim with animated progress bar |
| Source reference | Short AI-generated source note per claim |
| Highlighted output | Color-coded inline highlights (green/yellow/red) |
| Audit panel | Right-side scrollable report with all claims |
| Analysis modes | Lenient / Standard / Strict |
| Demo mode | Works without API key using simulated data |
| Interactive | Click any highlight or card to cross-link both views |

---

## How It Works

1. User pastes LLM text → clicks **Analyze**
2. Flask calls Claude twice:
   - **Prompt 1:** "Extract all factual claims as a JSON array"
   - **Prompt 2:** "For each claim, return status + confidence + source as JSON"
3. Frontend highlights text inline and builds the audit panel
4. Clicking a highlight or card cross-activates both views

---

## Demo Mode (No API Key)

If `ANTHROPIC_API_KEY` is not set, the app runs in demo mode:
- Uses the first 8 sentences from the input
- Returns simulated verdicts (mixed verified/unverified/hallucination)
- A yellow notice appears in the UI
- Useful for UI demos without burning API credits
